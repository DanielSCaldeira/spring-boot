package br.com.primeirocrudspring.springbootcommsql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootComMsqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
